package ca.gbc.productservice;

import org.testcontainers.containers.MongoDBContainer;

public abstract class AbstractContainerBaseTest {
    static final MongoDBContainer MONGO_DB_CONTAINER;

    static {
        MONGO_DB_CONTAINER = new MongoDBContainer("mongo:4.4.6");
        MONGO_DB_CONTAINER.start();
    }
}