package ca.gbc.productservice;

import ca.gbc.productservice.controller.ProductController;
import ca.gbc.productservice.dto.ProductRequest;
import ca.gbc.productservice.dto.ProductResponse;
import ca.gbc.productservice.repository.ProductRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ProductServiceApplicationTests extends AbstractContainerBaseTest {

    @Autowired
    private ProductController productController;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private MockMvc mockMvc;

    @DynamicPropertySource
    static void setProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.data.mongodb.uri", MONGO_DB_CONTAINER::getReplicaSetUrl);
    }

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
        productRepository.deleteAll();
    }

    @Test
    void testCreateProduct() throws Exception {
        ProductRequest productRequest = new ProductRequest();
        productRequest.setName("Test Product");
        productRequest.setDescription("Test Product Description");
        productRequest.setPrice(BigDecimal.valueOf(100.00));

        String productRequestJson = objectMapper.writeValueAsString(productRequest);

        mockMvc.perform(post("/api/v1/product").contentType(MediaType.APPLICATION_JSON).content(productRequestJson)).andExpect(status().isCreated());

        assertEquals(1, productRepository.findAll().size());
    }

    @Test
    void testGetAllProducts() throws Exception {
        ProductRequest productRequest = new ProductRequest();
        productRequest.setName("Test Product");
        productRequest.setDescription("Test Product Description");
        productRequest.setPrice(BigDecimal.valueOf(100.00));

        String productRequestJson = objectMapper.writeValueAsString(productRequest);

        mockMvc.perform(post("/api/v1/product").contentType(MediaType.APPLICATION_JSON).content(productRequestJson)).andExpect(status().isCreated());

        ResultActions result = mockMvc.perform(get("/api/v1/product")).andExpect(status().isOk());

        String resultJson = result.andReturn().getResponse().getContentAsString();
        ProductResponse[] productResponse = objectMapper.readValue(resultJson, ProductResponse[].class);
        assertEquals(1, productResponse.length);
    }
}